from PIL import Image
import operator
import csv
import os

pixellist = []
for i in xrange(4):
    for j in xrange(8):
        filename = "./images/X"+str(i+1)+"Y"+str(j+1)+".png"
        img = Image.open(filename)
        siz=img.size
        grey_im = img.convert('LA')
        data=grey_im.load()
        totalpixels = 0
        for L in range(0,siz[0]):
            for k in range(0,siz[1]):
                r = data[L,k]
                totalpixels = totalpixels + (float(r[0])/float(r[1]))
        pixellist.append(totalpixels)
key = (str(int(pixellist.index(max(pixellist))) + 1))
file = open('./transferfiles/datatransfer.txt', 'w')
file.write(key)
file.close()

