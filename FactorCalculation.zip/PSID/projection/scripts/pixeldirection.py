from PIL import Image
import operator
import csv
import time

directions, pixellist = [], []
neutralpixels = 0.
bin1, bin2 = 0, 0
images = ["./images/nn.png", "./images/ne.png", "./images/ee.png", "./images/se.png",
            "./images/ss.png", "./images/sw.png", "./images/ww.png", "./images/nw.png"]
topimage = ''
#Finding neutral location pixelation
im = Image.open("./images/Neutral.png")
grey_im = im.convert('LA')

siz=grey_im.size
data=grey_im.load()
for L in range(0,siz[0]):
            for k in range(0,siz[1]):
                r = data[L,k]
                neutralpixels = neutralpixels + (float(r[0])/float(r[1]))

for item in images:
    im = Image.open(item)
    grey_im = im.convert('LA')
    data=grey_im.load()
    totalpixels = 0.
    for L in range(0,siz[0]):
            for k in range(0,siz[1]):
                r = data[L,k]
                totalpixels = totalpixels + (float(r[0])/float(r[1]))
    pixellist.append(totalpixels)

topimage = pixellist.index(max(pixellist))
if int(max(pixellist)) <= neutralpixels: topimage = 8


file = open('./transferfiles/direction.txt', 'w')
file.write(str(topimage))
file.close()
