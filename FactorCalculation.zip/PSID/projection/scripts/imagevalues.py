from PIL import Image
import operator
import csv

im = Image.open("./images/final.png") 
grey_im = im.convert('LA')
totalpixels, perimeter = 0, 0
data=grey_im.load()
siz=grey_im.size
for L in range(0,siz[0]):
    for k in range(0,siz[1]):
        r = data[L,k]
        if r[0] != 0:
            totalpixels = totalpixels + (float(r[0])/float(r[1]))
            r1,r2,r3,r4=(1,255),(1,255),(1,255),(1,255)
            try:
                r1 = data[L,k+1]
            except IndexError:
                pass
            try:
                r2 = data[L,k-1]
            except IndexError:
                pass
            try:
                r3 = data[L+1,k]
            except IndexError:
                pass
            try:
                r4 = data[L-1,k]
            except IndexError:
                pass
            if r1[0] == 0 or r2[0] == 0 or r3[0] == 0 or r4[0] == 0:
                perimeter = perimeter + 1
            
im = Image.open("./images/scale.png")
grey_im = im.convert('LA')
scale = 0
data=grey_im.load()
for L in range(0,siz[0]):
    for k in range(0,siz[1]):
        r = data[L,k]
        if r[0] !=0:
            scale = scale + (float(r[0])/float(r[1]))


file = open('./transferfiles/area.txt', 'w')
file.write(str(totalpixels))
file.close()
file = open('./transferfiles/perimeter.txt', 'w')
file.write(str(perimeter))
file.close()
file = open('./transferfiles/scale.txt', 'w')
file.write(str(scale))
file.close()

                
            
                                        
            
