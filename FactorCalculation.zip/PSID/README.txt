Required Software: Python 3.6.3 (Libraries: NumPy, BioPython, ProDy), Pymol 2.0.1, FoldX 4

1. Download zipped folder
2. Download and save FoldX Files (�FoldX� and �rotabase.txt�): �./pythonScripts/�
3. Save PDB file with unmodified potential scaffold: �./pdbFiles/starting/[PDB ID]_[Chain ID].pdb�
4. Update scaffold list: �./textFiles/scaffoldlist.txt�
	a. Line 1: [PDB ID]_[Chain ID]
	b. Line 2: Amino acids of proposed scaffold (remove unstructured termini & with �X� at paratope positions 
5. Remove old files
	a. all files within: "./factors/"
	b. readable paratope key: "./textFiles/paratopeKey/readablekey.txt"
6. From terminal, change directory: �./pythonScripts/�
7. Run command: �pymol pid_main.py -c�
	a. Factors (except Paratope Stiffness and FoldX) are saved: �./factors/�
	b. Paratope can be verified:�./textFiles/paratopeKey/readablekey.txt�
	c. 2D Projection Images can be verified: �./projection/images/�
8. Run command: �python pid_prody.py�
	a. Paratope Stiffness is saved: �./factors/
9. Run command: �python foldxprep.py�
	a. FoldX mutations to be made are saved: �./textFiles/foldXmutants/�
10. Run command: �python pid_foldx.py #�
	a. Note: FoldX Calculations could take hours
	b. # is the index (starting with 0) of the scaffold based upon: �./factor/pdb_order.txt�
		i. This index can be used to run FoldX in parallel
11. Run command: �python foldxsummary.py�
	a. FoldX DDG and Total Energy are saved: �./factors/�




