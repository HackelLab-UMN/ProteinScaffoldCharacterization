import os
from os.path import isfile,join
import argparse

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('taski',type=int)
    args= parser.parse_args()

    temp = [line.rstrip('\n\r') for line in open('../factor/pdb_order.txt')]
    pdb=[]
    for i in range(0,len(temp)):
        pdb.append(temp[i])

    buildpdb(pdb[args.taski])       

def buildpdb(pdb):
    repairline=('./FoldX --command=RepairPDB --pdb-dir=../pdbFiles/trimmed --pdb='+pdb+'.pdb --output-dir=../pdbFiles/repaired')
    os.system(repairline)
    line=('./FoldX --command=BuildModel --pdb-dir=../pdbFiles/repaired --pdb='+pdb+'_Repair.pdb --mutant-file=../textFiles/foldXmutants/individual_list_'+pdb+'.txt --output-dir=../pdbFiles/mutant')
    os.system(line)

if __name__ == '__main__':
    main()
