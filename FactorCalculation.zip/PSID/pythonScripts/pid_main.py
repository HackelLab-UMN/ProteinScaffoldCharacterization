# PyMOL library check
try:
    from pymol import cmd, stored
except ImportError:
    print 'PyMOL libraries not detected, be sure you are running script through PyMOL interpreter.'
    sys.exit(0)
import os
import math
import sys
import numpy
import pickle
from pymol.exporting import _resn_to_aa as one_letter


def preview():          
    cmd.delete("all")
    cmd.set("dot_solvent", 1) #size of water
    cmd.set("ray_opaque_background",1)
    time.sleep(.5)
    global startdir
    startdir=os.getcwd()

def main():           
    temp = [line.rstrip('\n\r') for line in open('../textFiles/scaffoldlist.txt')]

    pdb, scaffoldaa =[],[]
    for i in range(0,len(temp),2): #Save list of scaffolds + Sequences
        pdb.append(temp[i])
        scaffoldaa.append(temp[i+1])
    

    for i in range(len(pdb)): #for each scaffold calculate the properties and save to file
        try:
            print "Starting analysis on scaffold:", pdb[i]
            cmd.delete("all")
            os.chdir('../pdbFiles/starting')
            cmd.load((pdb[i])+'.pdb')
            os.chdir(startdir)
            stored.aa=[]
            cmd.iterate("%s and n. ca" % pdb[i], "stored.aa.append((resi, one_letter[resn], ss))") #list of aa by number, letter, ss type
            start,end,paratope=identify(stored.aa,scaffoldaa[i],pdb[i]) #Find and save the index of the ordered start, end, and paratope regions
            size=end-start+1 #Calculate the size of the scaffold with ends removed
            newsasa=newsolvent(start,end,pdb[i]) #calc newsasa and remove tails and save trimmed file for FoldX and Prody
            stored.aa=[]
            cmd.iterate("%s and n. ca" % pdb[i], "stored.aa.append((resi, one_letter[resn], ss))") #redo list with ends removed
            cdegree,corder,longdegree,pcdegree,pcorder=contact(stored.aa,paratope) #calculate contact parameters 
            sspercent=sscalc(stored.aa) #calc percent residues in alpha+beta
            npsa=buriednonpolarsasa(stored.aa) #calc non-polar buried surface area
            runmutagenesis(paratope) #turn paratope into Ala           
            parasasa,chargedsasa,polarsasa,hphobicsasa=surface(stored.aa,paratope) #calc 3D solvent expose surface areas
            psep,pangle=parasep(paratope) #calc paratope sep and angle 
            projperi,projarea=projection(paratope) #calc 2D projection terms

            savefactors(pdb[i],size,newsasa,cdegree,corder,longdegree,pcdegree,pcorder,sspercent,npsa,parasasa,chargedsasa,polarsasa,hphobicsasa,psep,pangle,projperi,projarea)
        except Exception as e:
            print (e,pdb[i])
            os.chdir(startdir)
            continue
        
''''''
def identify(storedaa,scaffoldaa,pdb):
    for i in range(len(storedaa)-2):
        if scaffoldaa[:3]==''.join([storedaa[i][1],storedaa[i+1][1],storedaa[i+2][1]]):
            start=int(storedaa[i][0])
        if scaffoldaa[-3:]==''.join([storedaa[i][1],storedaa[i+1][1],storedaa[i+2][1]]):
            end=int(storedaa[i+2][0])
    indices = [i for i, x in enumerate(scaffoldaa) if x == "X"]
    paratope = numpy.asarray(indices)+start

    resi_ind,resi_aa,j= [],[],0
    for i in range(len(paratope)):
        for j in range (i,len(storedaa)):
            if int(paratope[i])==int(storedaa[j][0]):
                resi_ind.append(int(storedaa[j][0]))
                resi_aa.append(storedaa[j][1])

    aakey=open('../textFiles/paratopeKey/readablekey.txt','a')
    aakey.write("%s\n%s\n%s\n%s\n%s\n" % (pdb,start,end,resi_ind,resi_aa))
    aakey.close()
    
    pickle.dump(resi_ind,open('../textFiles/paratopeKey/resi_ind'+pdb+'.txt','w'))
    pickle.dump(resi_aa,open('../textFiles/paratopeKey/resi_aa'+pdb+'.txt','w'))

    return start, end, paratope
''''''
def newsolvent(start,end,pdb):
    presolvent = cmd.get_area("resi "+str(start)+"-"+str(end))
    cmd.remove("not resi "+str(start)+"-"+str(end))
    postsolvent = cmd.get_area('all')
    newsasa=(postsolvent - presolvent)
    os.chdir('../pdbFiles/trimmed')
    cmd.save(pdb+'.pdb')
    os.chdir(startdir)
    return newsasa
''''''
def contact(storedaa,paratope):
    cutoffsq=64
    cdegree,totalsep,longsep,pcdegree,ptotalsep=0,0,0,0,0
    cbeta=cmd.get_model('name cb or (resn gly and name ca)')
    atomloc=[]
    for a in cbeta.atom:
        atomloc.append(a.coord)
    for i in range(len(atomloc)):
        for j in range (i+1,len(atomloc)):
            distsq=(atomloc[i][0]-atomloc[j][0])**2+(atomloc[i][1]-atomloc[j][1])**2+(atomloc[i][2]-atomloc[j][2])**2
            if distsq>cutoffsq:
                cdegree=cdegree+1
                totalsep=totalsep+j-i
                if j-i>12:
                    longsep=longsep+1
                if (i+int(storedaa[0][0]) in paratope) ^ (j+int(storedaa[0][0]) in paratope):
                    pcdegree=pcdegree+1
                    ptotalsep=ptotalsep+j
    corder=float(totalsep)/(cdegree*len(storedaa))
    longdegree=float(longsep)/len(storedaa)
    pcorder=float(ptotalsep)/(pcdegree*len(paratope))
    return cdegree,corder,longdegree,pcdegree,pcorder
''''''
def sscalc(storedaa):
    ssamino=0
    for i in range(len(storedaa)):
        if storedaa[i][2]=='H' or storedaa[i][2]=='S':
            ssamino=ssamino+1
    return 100*(float(ssamino)/len(storedaa))
''''''
def buriednonpolarsasa(storedaa):
    dummy = [line.rstrip('\n\r') for line in open('../textFiles/AASASA.txt')]
        
    aa, asa =[],[]
    polar='QNHSTYCW'
    for i in range(0,len(dummy),2):
        if not(dummy[i] in polar):
            aa.append(dummy[i])
            asa.append(int(dummy[i+1]))    

    foldedsasa = 0
    linearsasa = 0
    for i in range(0,len(storedaa)):
        for j in range(0,len(aa)):
            if storedaa[i][1]==aa[j]:
                linearsasa=linearsasa+asa[j]
                foldedsasa=foldedsasa+cmd.get_area("resi "+storedaa[i][0])
    return linearsasa-foldedsasa
''''''
def runmutagenesis(paratope):   
    for item in paratope:
        cmd.wizard("mutagenesis")
        cmd.refresh_wizard()
        cmd.get_wizard().do_select("resi "+str(item))
        cmd.get_wizard().set_mode("ALA")
        cmd.get_wizard().apply()
        cmd.set_wizard()
    cmd.refresh
''''''
def surface(storedaa,paratope):
    charge='RKDE'
    polar='QNHSTYCW'
    hydrophobic='AILMFVPG'
    pasa,csa,posa,hsa= 0,0,0,0
    for i in range(len(storedaa)):
        if int(storedaa[i][0]) in paratope:
            pasa=pasa+cmd.get_area("resi "+storedaa[i][0])
        else:
            if storedaa[i][1] in charge:
                csa=csa+cmd.get_area("resi "+storedaa[i][0])
            if storedaa[i][1] in polar:
                posa=posa+cmd.get_area("resi "+storedaa[i][0])
            if storedaa[i][1] in hydrophobic:
                hsa=hsa+cmd.get_area("resi "+storedaa[i][0])
    return pasa, csa, posa, hsa
''''''
def parasep(paratope):
    paratopeoneend,paratopetwostart=[],[]
    for i in range(len(paratope)-1):
        if paratope[i+1]!=paratope[i]+1:
            paratopeoneend=paratope[i]
            paratopetwostart=paratope[i+1]

    paraone=cmd.get_model('resi '+str(paratope[0])+'-'+str(paratopeoneend))
    x1,y1,z1=[],[],[]
    for a in paraone.atom:
        x1.append(a.coord[0])
        y1.append(a.coord[1])
        z1.append(a.coord[2])
    paraoneCOV=[numpy.mean(x1),numpy.mean(y1),numpy.mean(z1)]

    paratwo=cmd.get_model('resi '+str(paratopetwostart)+'-'+str(paratope[-1]))
    x2,y2,z2=[],[],[]
    for a in paratwo.atom:
        x2.append(a.coord[0])
        y2.append(a.coord[1])
        z2.append(a.coord[2])
    paratwoCOV=[numpy.mean(x2),numpy.mean(y2),numpy.mean(z2)]


    allresi=cmd.get_model('all')
    xall,yall,zall=[],[],[]
    for a in allresi.atom:
        xall.append(a.coord[0])
        yall.append(a.coord[1])
        zall.append(a.coord[2])
    allCOV=[numpy.mean(xall),numpy.mean(yall),numpy.mean(zall)]
    

    psep=((paraoneCOV[0]-paratwoCOV[0])**2+(paraoneCOV[1]-paratwoCOV[1])**2+(paraoneCOV[2]-paratwoCOV[2])**2)**0.5
    poneall=((paraoneCOV[0]-allCOV[0])**2+(paraoneCOV[1]-allCOV[1])**2+(paraoneCOV[2]-allCOV[2])**2)**0.5
    ptwoall=((paratwoCOV[0]-allCOV[0])**2+(paratwoCOV[1]-allCOV[1])**2+(paratwoCOV[2]-allCOV[2])**2)**0.5

    pangle=math.degrees(math.acos((poneall**2+ptwoall**2-psep**2)/(2*poneall*ptwoall)))

    return psep, pangle
''''''
def projection(paratope):
    os.chdir('../projection')
    cmd.hide("all")
    cmd.show("surface")
    cmd.set("depth_cue")
    cmd.set("ambient", 2)
    cmd.set("fog", 0)
    cmd.set("light_count", 1)
    cmd.set("fog_start", 0)

    periarea, surfacearea = [], []

    paratopeoneend,paratopetwostart=[],[]
    for i in range(len(paratope)-1):
        if paratope[i+1]!=paratope[i]+1:
            paratopeoneend=paratope[i]
            paratopetwostart=paratope[i+1]
    
    cmd.bg_color("black")
    cmd.color("black", "all")
    cmd.color("white", "resi "+str(paratope[0])+"-"+str(paratopeoneend)+ " or resi "+str(paratopetwostart)+"-"+str(paratope[-1]))
    cmd.orient()
    cmd.origin("resi "+str(paratope[0])+"-"+str(paratopeoneend)+ " or resi "+str(paratopetwostart)+"-"+str(paratope[-1]))
    cmd.zoom(selection="all", buffer=2.0, state=0, complete=1, animate=0)
    cmd.capture
    cmd.set("fog_start", 0)
    
    for i in range(4):
        cmd.turn("x", 45)
        for j in range(8):
            cmd.turn("y", 45)
            cmd.refresh()
            cmd.capture
            cmd.png("./images/X"+str(i+1)+"Y"+str(j+1)+".png", 100,100, ray=0,quiet=1)
            cmd.png("./images/X"+str(i+1)+"Y"+str(j+1)+".png", dpi=10,ray=0, quiet=1)

    cmd.do("run ./scripts/toppixel.py")
    
    file = open("./transferfiles/datatransfer.txt", "r")
    lines = file.readlines()
    lines = int(lines[0])
    
    
    cmd.rotate("x", 180)
    cmd.turn('x', (45 + 45*((lines-1)/8)))
    cmd.turn('y', (45*(lines%8)))
    cmd.refresh()

    radlist =  [23,16,8,4,2,1,1]
    pushname = ["./images/nn.png", "./images/ne.png", "./images/ee.png", "./images/se.png",
                "./images/ss.png", "./images/sw.png", "./images/ww.png", "./images/nw.png"]

    for value in radlist:
        cmd.refresh()
        cmd.capture
        cmd.png("./images/Neutral.png", 100,100,ray=0, quiet=1)
        cmd.png("./images/Neutral.png", dpi=10,ray=0, quiet=1)
        for i in range(len(pushname)):
            cmd.turn('z', 45*i)
            cmd.turn('y', value)
            cmd.turn('z', -45*i)
            cmd.refresh()
            cmd.capture
            cmd.png(pushname[i],100,100, quiet=1)
            cmd.png(pushname[i],dpi=10, quiet=1)
            cmd.turn('z', 45*i)
            cmd.turn('y', -1*value)
            cmd.turn('z', -45*i)
        cmd.do("run ./scripts/pixeldirection.py")
        file = open("./transferfiles/direction.txt", "r")
        lines = file.readlines()
        lines = int(lines[0])
        if lines < 8:
            cmd.turn('z', 45*lines)
            cmd.turn('y', value)
            cmd.turn('z', -45*lines)

    cmd.refresh()
    cmd.capture
    cmd.png("./images/final.png", 1000,1000, ray=0,quiet=1)
    cmd.png("./images/final.png", dpi=10,ray=0, quiet=1)

    cmd.disable('all')
    paracenter=cmd.get_model("resi "+str(paratope[0])+"-"+str(paratopeoneend)+ " or resi "+str(paratopetwostart)+"-"+str(paratope[-1]))
    xp,yp,zp=[],[],[]
    for a in paracenter.atom:
        xp.append(a.coord[0])
        yp.append(a.coord[1])
        zp.append(a.coord[2])
    pCOV=[numpy.mean(xp),numpy.mean(yp),numpy.mean(zp)]
    
    cmd.pseudoatom("scaler", pos = pCOV, color='white')
    cmd.set("fog", 0)
    cmd.show("spheres")
    cmd.refresh()
    cmd.capture
    cmd.png("./images/scale.png",1000,1000,ray=0, quiet=1)
    cmd.png("./images/scale.png", dpi=10,ray=0, quiet=1)

    cmd.do("run ./scripts/imagevalues.py")
    
    file = open("./transferfiles/area.txt", "r")
    lines = file.readlines()
    area = (float(lines[0]))
    file = open("./transferfiles/perimeter.txt", "r")
    lines = file.readlines()
    perimeter = float(lines[0])
    file = open("./transferfiles/scale.txt", "r")
    lines = file.readlines()
    scale = (float(lines[0]))
    
    os.chdir(startdir)
    return perimeter/scale, area/scale
''''''
def savefactors(pdb,size,newsasa,cdegree,corder,longdegree,pcdegree,pcorder,sspercent,NPSA,parasasa,chargedsasa,polarsasa,hphobicsasa,psep,pangle,projperi,projarea):
    output=[size,newsasa,cdegree,corder,longdegree,pcdegree,pcorder,sspercent,NPSA,parasasa,chargedsasa,polarsasa,hphobicsasa,psep,pangle,projperi,projarea]
    factor=['Size','New SASA','Contact Degree','Contact Order','Long Range Contact Degree','Paratope Contact Degree','Paratope Contact Order','Secondary Structure Percent','Buried NPSA','Paratope SASA','Charged SASA','Polar SASA','Hydrophobic SASA','Paratope Separation','Paratope Angle','Projected Paratope Perimeter','Projected Paratope Area']
    for i in range(len(factor)):
        temp=open('../factor/'+factor[i]+'.txt','a')
        temp.write('%s\n' % output[i])
        temp.close()

    pdborder=open('../factor/pdb_order.txt','a')
    pdborder.write('%s\n' % pdb)
    pdborder.close()
    

''''''
preview()
print ('Starting')
main()
print ('Complete')

