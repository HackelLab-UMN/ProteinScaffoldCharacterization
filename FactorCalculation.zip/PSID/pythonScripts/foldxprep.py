import os
from os.path import isfile,join
import random
import csv
import pickle
import time
import numpy

aas = {'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C',
       'GLU':'E','GLN':'Q','GLY':'G','HIS':'H','ILE':'I',
       'LEU':'L','LYS':'K','MET':'M','PHE':'F','PRO':'P',
       'SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V'}


def main():
    dist_type = 'NNK'
    distributions = LoadDistributions()

    temp = [line.rstrip('\n\r') for line in open('../factor/pdb_order.txt')]
    pdbfinal=[]
    for i in range(0,len(temp)):
        pdbfinal.append(temp[i])
        
    temp = [line.rstrip('\n') for line in open('../textFiles/paratopeKey/readablekey.txt')]
    pdb,start,end,resi_ind,resi_aa=[],[],[],[],[]
    

    for i in range(0,len(temp),5):
        if temp[i] in pdbfinal:
            pdb.append(temp[i])

    for i in range(len(pdb)):
        resi_ind.append(pickle.load(open('../textFiles/paratopeKey/resi_ind'+pdb[i]+'.txt','rb')))
        resi_aa.append(pickle.load(open('../textFiles/paratopeKey/resi_aa'+pdb[i]+'.txt','rb')))
        chain=pdb[i][5]
        clone_count=50
        mutants = Library(clone_count,distributions['NNK'],resi_ind[i],resi_aa[i],pdb[i],chain)


def Library(clone_count,distribution,resi_ind,resi_aa,pdb,chain):
    mutants = []
    dist = distribution[0]
    
    aas = 'ACDEFGHIKLMNPQRSTVWY'

    for c in range(clone_count): 
        rands = [random.uniform(0,1) for i in range(len(resi_ind))]
        mutant = ''
        for ind,i,a in zip(range(len(resi_ind)),resi_ind,resi_aa):
            mut = aas[[j for j in range(len(dist)) if sum(dist[0:j+1]) > rands[ind]][0]]
            mutant += a+chain+str(i)+mut+','
        mutants.append(mutant[:-1]+';')

    # write to file
    f = open('../textFiles/foldXmutants/individual_list_'+pdb+'.txt','w')
    for item in mutants:
        f.write('%s\n' % item)
    f.close()
    return mutants

def LoadDistributions():
    data,distributions = [],{}
    destination = os.getcwd()
    with open('../textFiles/distributions.csv', 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            data.append(row)
    for i in range(len(data)):
        if data[i][0] == 'ID:':
            for j in range(i+2,len(data)):
                if ''.join(data[j]) == '': break
                distributions[data[i][1]] = [[float(data[k][kk]) for kk in range(1,21)] for k in range(i+2,j+1)]

    return distributions


if __name__ == '__main__':
    main()
