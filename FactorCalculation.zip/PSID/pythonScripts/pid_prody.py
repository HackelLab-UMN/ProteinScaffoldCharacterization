from prody import *
from pylab import *
import os
import numpy
import sys
import pickle
ion()

def main():
    startdir=os.getcwd()

    temp = [line.rstrip('\n\r') for line in open('../factor/pdb_order.txt')]
    pdbfinal=[]
    for i in range(0,len(temp)):
        pdbfinal.append(temp[i])

    temp = [line.rstrip('\n\r') for line in open('../textFiles/paratopeKey/readablekey.txt')]
    pdb,start,resi_ind=[],[],[]

    for i in range(0,len(temp),5):
        if temp[i] in pdbfinal:
            pdb.append(temp[i])
            start.append(int(temp[i+1]))    

    for i in range(0,len(pdb)):
        resi_ind.append(pickle.load(open('../textFiles/paratopeKey/resi_ind'+pdb[i]+'.txt','rb')))
        pdbf= parsePDB('../pdbFiles/trimmed/'+pdb[i]+'.pdb')
        calphas=pdbf.select('protein and name CA')
        anm = ANM('ANM analysis')
        anm.buildHessian(calphas, cutoff=13.0)
        anm.calcModes(n_modes='all')
        stiffness=calcMechStiff(anm,calphas)
        meanStiff = np.array([np.mean(stiffness, axis=0)])
        averagestiff=meanStiff[0]
        mea=numpy.mean(averagestiff)
        st=numpy.std(averagestiff)
        zstiff=(averagestiff-mea)/st
        
        pstiff=[]
        for j in resi_ind[i]:
            pstiff.append(zstiff[j-start[i]])
        pstiffout=open('../factor/Paratope Stiffness.txt','a')
        pstiffout.write('%s\n' % numpy.mean(pstiff))
        pstiffout.close()
print('Starting ProDy')
main()
print('Complete')
