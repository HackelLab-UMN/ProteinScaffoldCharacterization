import os
from os.path import isfile,join
import numpy



def main():

    temp = [line.rstrip('\n\r') for line in open('../factor/pdb_order.txt')]
    pdb,start,end,resi_ind,resi_aa=[],[],[],[],[]
    

    for i in range(0,len(temp)):
        pdb.append(temp[i])
    for i in range(len(pdb)):
        mut,ddg=[],[]
        tempmut,tempwt=[],[]
        with open('../pdbFiles/mutant/Raw_'+pdb[i]+'_Repair.fxout','r') as efile:
            efile=efile.readlines()[9:]
            linecount=0;
            for line in efile:
                if linecount %2 ==0:
                    d=[]
                    fields= line.split('\t')
                    d.append(fields)
                    tempmut.append(float(d[0][1]))
                else:
                    d = []
                    fields = line.split('\t')
                    d.append(fields)
                    tempwt.append(float(d[0][1]))
                linecount=linecount+1
            for j in range(len(tempmut)):
                if not ((tempmut[j] in mut) and (tempmut[j]-tempwt[j]) in ddg):
                    mut.append(tempmut[j])
                    ddg.append(tempmut[j]-tempwt[j])

        ddgout=open('../factor/FoldX DDG.txt','a')
        ddgout.write('%s\n' % numpy.mean(ddg))
        ddgout.close()
        engout=open('../factor/FoldX Energy.txt','a')
        engout.write('%s\n' % numpy.mean(mut))
        engout.close()

if __name__ == '__main__':
    main()
